const crypto = require("crypto");
const readline = require("readline");

const clientId = "7959c89772d662ff740ec0533ba1873e";
const redirectUri = "http://localhost:3000/callback";
const verifier = crypto.randomBytes(32).toString("base64url");
const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");

console.log("\n1. Open this URL in your browser and click Authorize:\n");
console.log(`https://opensource-demo.orangehrmlive.com/web/index.php/oauth2/authorize?response_type=code&client_id=${clientId}&redirect_uri=${redirectUri}&code_challenge=${challenge}&code_challenge_method=S256\n`);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question("2. Paste the code= value from the redirected URL here: ", async (code) => {
  const res = await fetch("https://opensource-demo.orangehrmlive.com/web/index.php/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      client_id: clientId,
      redirect_uri: redirectUri,
      code: code.trim(),
      code_verifier: verifier,
    }),
  });
  console.log("\nResponse:\n", await res.json());
  rl.close();
});
