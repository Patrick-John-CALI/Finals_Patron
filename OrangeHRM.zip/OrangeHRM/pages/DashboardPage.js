
export class DashboardPage {
  constructor(page) {
    this.page = page;
    this.adminMenu = page.getByRole('link', {
      name: 'Admin'
    });
    this.dashboardHeading = page.getByRole('heading', {
      name: 'Dashboard'
    });
  }

  async openAdmin() {
    await this.adminMenu.click();
  }
}