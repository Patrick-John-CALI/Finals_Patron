
export class AdminPage {
  constructor(page) {
    this.page = page;

    this.addButton = page.getByRole('button', {
      name: 'Add'
    });

    this.usernameFilter = page.locator(
      'form input'
    ).nth(1);

    this.searchButton = page.getByRole('button', {
      name: 'Search'
    });

    this.resetButton = page.getByRole('button', {
      name: 'Reset'
    });

    this.userTable = page.getByRole('table');
  }

  async goto() {
    await this.page.goto('/web/index.php/admin/viewSystemUsers');
  }

  async searchUser(username) {
    await this.usernameFilter.fill(username);
    await this.searchButton.click();
  }

  async openAddUser() {
    await this.addButton.click();
  }
}
