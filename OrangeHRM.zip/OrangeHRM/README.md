# OrangeHRM Week 2 - Playwright POM Automation

## Project Overview

This project automates OrangeHRM Admin module scenarios using
Playwright and the Page Object Model (POM).

Website:
https://opensource-demo.orangehrmlive.com/

## Technologies

- JavaScript
- Playwright
- Node.js
- Visual Studio Code
- Page Object Model
- Playwright APIRequestContext

## Installation

Install dependencies:

    npm install

Install Playwright browsers:

    npx playwright install

## Environment Setup

1. Copy .env.example.
2. Rename the copied file to .env.
3. Enter the administrator credentials.
4. Configure optional ESS credentials and synthetic test data.
5. Configure the documented API endpoint and Bearer token
   only if they are provided for the assigned environment.

Never upload .env to GitHub.

## Run All Tests

    npx playwright test

## Run UI Tests

    npx playwright test tests/ui

## Run API Tests

    npx playwright test tests/api

## Run Tests with Browser Visible

    npx playwright test --headed

## Run Individual Test Files

    npx playwright test tests/ui/login.spec.js

    npx playwright test tests/ui/navigation.spec.js

    npx playwright test tests/ui/admin-auth.spec.js

    npx playwright test tests/ui/admin-users.spec.js

    npx playwright test tests/ui/admin-edge.spec.js

    npx playwright test tests/api/admin-api.spec.js

## View HTML Report

    npx playwright show-report

## BDD Scenario Coverage

| BDD ID | Scenario | Test File |
|---|---|---|
| ADM-01 | Admin login and access | login.spec.js |
| ADM-01 | Admin module navigation | navigation.spec.js |
| ADM-02 | ESS denied Admin access | admin-auth.spec.js |
| ADM-03 | Expired session protection | admin-auth.spec.js |
| ADM-04 | User list and filters | admin-users.spec.js |
| ADM-05 | Exact username search | admin-users.spec.js |
| ADM-06 | Create valid user | admin-users.spec.js |
| ADM-07 | Required-field validation | admin-users.spec.js |
| ADM-08 | Duplicate username rejection | admin-users.spec.js |
| ADM-09 | Whitespace and case search | admin-edge.spec.js |
| ADM-10 | Username boundary validation | admin-edge.spec.js |
| ADM-11 | Rapid repeated Save | admin-edge.spec.js |
| ADM-12 | Authorized API retrieves user data | admin-api.spec.js |
| ADM-13 | API authorization rejection | admin-api.spec.js |
| ADM-14 | Interrupted connection | admin-edge.spec.js |
| ADM-15 | Long names at narrow viewport | admin-edge.spec.js |

## Safety and Environment Notes

Some scenarios require an isolated test environment.

- ADM-02 requires an ESS account without Admin permissions.
- ADM-05 and ADM-09 require an existing synthetic username.
- ADM-06, ADM-08, ADM-10, ADM-11, and ADM-14 may create test data.
- ADM-10 requires the actual username length and character rules.
- ADM-12 and ADM-13 require a documented API endpoint and token.
- ADM-14 requires a configured request URL pattern.
- ADM-15 requires a seeded account with a long employee name.

User creation is disabled by default.

Tests with missing prerequisites are skipped, not counted as passed.