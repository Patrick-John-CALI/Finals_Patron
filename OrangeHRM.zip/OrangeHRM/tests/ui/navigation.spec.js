import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { DashboardPage } from '../../pages/DashboardPage.js';
import { testData } from '../../test-data/testData.js';

test.beforeEach(async ({ page }) => {
  const login = new LoginPage(page);

  await login.goto();
  await login.login(
    testData.username,
    testData.password
  );

  await expect(page).toHaveURL(/dashboard/);
});

test('NAV-01 - Dashboard is displayed after login', async ({ page }) => {
  await expect(
    page.getByRole('heading', { name: 'Dashboard' })
  ).toBeVisible();
});

test('NAV-02 - Admin menu is visible', async ({ page }) => {
  const dashboard = new DashboardPage(page);

  await expect(dashboard.adminMenu).toBeVisible();
});

test('NAV-03 - Navigate to Admin module', async ({ page }) => {
  const dashboard = new DashboardPage(page);

  await dashboard.openAdmin();

  await expect(page).toHaveURL(/admin\/viewSystemUsers/);

  await expect(
    page.getByRole('heading', { name: 'System Users' })
  ).toBeVisible();
});
