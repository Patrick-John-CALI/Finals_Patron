
import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { testData } from '../../test-data/testData.js';

test('LOGIN-01 - Administrator logs in successfully', async ({ page }) => {
  const login = new LoginPage(page);

  await login.goto();
  await login.login(
    testData.username,
    testData.password
  );

  await expect(page).toHaveURL(/dashboard/);

  await expect(
    page.getByRole('heading', { name: 'Dashboard' })
  ).toBeVisible();
});

test('LOGIN-02 - Invalid username and password', async ({ page }) => {
  const login = new LoginPage(page);

  await login.goto();
  await login.login('invalid_user', 'wrong_password');

  await expect(
    page.getByText('Invalid credentials')
  ).toBeVisible();

  await expect(page).toHaveURL(/auth\/login/);
});

test('LOGIN-03 - Empty login fields', async ({ page }) => {
  const login = new LoginPage(page);

  await login.goto();
  await login.loginButton.click();

  await expect(
    page.getByText('Required', { exact: true }).first()
  ).toBeVisible();
});
