
import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { DashboardPage } from '../../pages/DashboardPage.js';
import { AdminPage } from '../../pages/AdminPage.js';
import { testData } from '../../test-data/testData.js';

test.beforeEach(async ({ page }) => {
  const login = new LoginPage(page);

  await login.goto();
  await login.login(
    testData.username,
    testData.password
  );

  await expect(page).toHaveURL(/dashboard/);
});

test('ADM-01 - Administrator login', async ({ page }) => {
  await expect(page).toHaveURL(/dashboard/);
  await expect(
    page.getByRole('heading', { name: 'Dashboard' })
  ).toBeVisible();
});

test('UI-02 - Dashboard navigation is available', async ({ page }) => {
  const dashboard = new DashboardPage(page);

  await expect(dashboard.adminMenu).toBeVisible();
  await expect(dashboard.dashboardHeading).toBeVisible();
});

test('ADM-01 - Open Admin module', async ({ page }) => {
  const dashboard = new DashboardPage(page);

  await dashboard.openAdmin();

  await expect(page).toHaveURL(/admin\/viewSystemUsers/);
  await expect(
    page.getByRole('heading', { name: 'System Users' })
  ).toBeVisible();
});

test('ADM-04 - Display system users list', async ({ page }) => {
  const admin = new AdminPage(page);

  await admin.goto();

  await expect(admin.userTable).toBeVisible();
  await expect(
    page.getByRole('button', { name: 'Search' })
  ).toBeVisible();
});

test('ADM-05 - Search for an existing username', async ({ page }) => {
  const admin = new AdminPage(page);

  await admin.goto();
  await admin.searchUser('Admin');

  await expect(
    page.getByRole('cell', { name: 'Admin', exact: true })
  ).toBeVisible();
});

test('ADM-06 - Open Add User form', async ({ page }) => {
  const admin = new AdminPage(page);

  await admin.goto();
  await admin.openAddUser();

  await expect(
    page.getByText('Add User', { exact: true })
  ).toBeVisible();

  await expect(
    page.getByText('User Role')
  ).toBeVisible();

  await expect(
    page.getByText('Employee Name')
  ).toBeVisible();
});
