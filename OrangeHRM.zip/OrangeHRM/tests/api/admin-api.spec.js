
import { test, expect, request } from '@playwright/test';

const baseURL =
  'https://opensource-demo.orangehrmlive.com';

const endpoint =
  '/web/index.php/api/v2/admin/users';

test('ADM-12 - Authorized API retrieves users', async () => {
  test.skip(
    !process.env.ORANGEHRM_API_TOKEN,
    'Requires an authorized OAuth access token'
  );

  const api = await request.newContext({
    baseURL,
    extraHTTPHeaders: {
      Authorization:
        `Bearer ${process.env.ORANGEHRM_API_TOKEN}`,
      Accept: 'application/json'
    }
  });

  try {
    const response = await api.get(endpoint);

    expect(response.ok()).toBeTruthy();

    const body = await response.json();

    expect(body).toBeDefined();

    // Check that sensitive credentials are not exposed.
    expect(JSON.stringify(body)).not.toMatch(
      /passwordHash|accessToken/i
    );
  } finally {
    await api.dispose();
  }
});

test('ADM-13A - API rejects missing authorization', async () => {
  const api = await request.newContext({ baseURL });

  try {
    const response = await api.get(endpoint);

    expect([401, 403]).toContain(response.status());
  } finally {
    await api.dispose();
  }
});

test('ADM-13B - API rejects invalid authorization', async () => {
  const api = await request.newContext({
    baseURL,
    extraHTTPHeaders: {
      Authorization: 'Bearer invalid_test_token',
      Accept: 'application/json'
    }
  });

  try {
    const response = await api.get(endpoint);

    expect([401, 403]).toContain(response.status());
  } finally {
    await api.dispose();
  }
});
