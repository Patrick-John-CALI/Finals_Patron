# Finals_Patron
Patron -  OrangeHRM (Human Resources Management): https://opensource-demo.orangehrmlive.com/ 

Packages need to install:
npm install -D dotenv @types/node

mkdir "folder name"
cd "folder name"
npm init playwright@latest

.env file
ORANGE_USERNAME=Admin
ORANGE_PASSWORD=admin123
ORANGE_API_TOKEN="7959c89772d662ff740ec0533ba1873e"
